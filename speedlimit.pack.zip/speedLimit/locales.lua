Locales = {}

Locales['fr'] = {
    ['radar_flash'] = 'Vous avez été flashé à ~y~%s~s~ km/h! Amende de : $~b~%s',
    ['bank_notification'] = 'Banque',
    ['fine_notification'] = 'Amende',
    ['bank_message'] = 'Vous avez été débité de $%s pour excès de vitesse.'
}

Locales['en'] = {
    ['radar_flash'] = 'You were caught speeding at ~y~%s~s~ km/h! Fine: $~b~%s',
    ['bank_notification'] = 'Bank',
    ['fine_notification'] = 'Fine',
    ['bank_message'] = 'You have been fined $%s for speeding.'
}

function _U(locale, entry, ...)
    if Locales[locale] and Locales[locale][entry] then
        return string.format(Locales[locale][entry], ...)
    else
        return 'Translation [' .. locale .. '][' .. entry .. '] does not exist'
    end
end
