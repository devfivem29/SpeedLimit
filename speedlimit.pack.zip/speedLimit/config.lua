Config = {}
Config.Locale = 'fr'
Config.Radars = {
    {
        position = vector3(257.53778076172, -945.81353759766, 29.368803024292),
        radius = 50.0,
        speedLimit = 90.0,
        tolerance = 10.0,
        blipSprite = 819,
        blipColour = 1,
        fineAmount = 25
    },
    
    {
        position = vector3(2062.5190429688,2606.2136230469,52.838859558105),
         radius = 100.0,
        speedLimit = 110,
        tolerance = 10.0,
         blipSprite = 819,
         blipColour = 1,
         fineAmount = 45
             -- Ajoutez d'autres radars ici
             -- Add more speed cameras here
           -- },
           -- {
        --position = vector3(2062.5190429688,2606.2136230469,52.838859558105),
       -- radius = 100.0,
      --  speedLimit = 110,
      --  tolerance = 10.0,
      --   blipSprite = 819,
       --  blipColour = 1,
      --   fineAmount = 45
     
     }
}
