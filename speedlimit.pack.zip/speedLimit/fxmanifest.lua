fx_version 'cerulean'
games { 'gta5' }
lua54 'yes'
author 'DevFivem29'
description 'Speed Radar Script for FiveM'
version '1.0.0'

shared_scripts {
    'config.lua',
    'locales.lua'
}

client_scripts {
    'client.lua'
}

server_scripts {
    'server.lua'
}

dependency '/assetpacks'